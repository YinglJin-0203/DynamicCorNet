#' Get path to an HTML file bundled with this package
#'
#' @param filename Name of the HTML file
#' @return Full file path as a character string
#' @keywords internal
html_path <- function(filename) {
  system.file("html", filename, package = "niehsFooter")
}

# -------------------------------------------------------------------------

#' NIEHS Footer Body HTML
#'
#' Returns the full NIEHS footer as an \code{htmltools::HTML} object,
#' ready to place at the bottom of a Shiny UI.
#'
#' @return An \code{\link[htmltools]{HTML}} object containing the NIEHS footer.
#' @export
#' @examples
#' \dontrun{
#' library(shiny)
#' library(niehsFooter)
#'
#' ui <- fluidPage(
#'   niehs_footer_tags(),  # JS assets in <head>
#'   # ... your app content ...
#'   niehs_footer()        # Footer at the bottom of <body>
#' )
#' }
niehs_footer <- function() {
  path <- html_path("footer.html")
  if (!file.exists(path)) stop("footer.html not found in package inst/html/")
  htmltools::HTML(readLines(path, warn = FALSE, encoding = "UTF-8") |>
                    paste(collapse = "\n"))
}

# -------------------------------------------------------------------------

#' NIEHS Footer Assets (JS)
#'
#' Returns the NIEHS footer JavaScript tags as an \code{htmltools::HTML}
#' object. Intended to be placed inside \code{tags$head()} or via
#' \code{\link{niehs_footer_tags}}.
#'
#' @return An \code{\link[htmltools]{HTML}} object with \code{<script>} tags.
#' @export
#' @examples
#' \dontrun{
#' library(shiny)
#' library(niehsFooter)
#'
#' ui <- fluidPage(
#'   tags$head(niehs_footer_assets()),
#'   niehs_footer()
#' )
#' }
niehs_footer_assets <- function() {
  path <- html_path("footerasset.html")
  if (!file.exists(path)) stop("footerasset.html not found in package inst/html/")
  htmltools::HTML(readLines(path, warn = FALSE, encoding = "UTF-8") |>
                    paste(collapse = "\n"))
}

# -------------------------------------------------------------------------

#' All NIEHS Footer Head Tags Combined
#'
#' Convenience wrapper that returns a \code{tags$head()} block containing
#' the NIEHS footer JS assets. Drop this into your Shiny UI alongside
#' \code{\link{niehs_footer}}.
#'
#' @return A \code{\link[shiny]{tags}} head element.
#' @export
#' @examples
#' \dontrun{
#' library(shiny)
#' library(niehsFooter)
#'
#' ui <- fluidPage(
#'   niehs_footer_tags(),
#'   # ... your app content ...
#'   niehs_footer()
#' )
#'
#' server <- function(input, output, session) {}
#' shinyApp(ui, server)
#' }
niehs_footer_tags <- function() {
  shiny::tags$head(
    niehs_footer_assets()
  )
}
