# niehsFooter

An R package that bundles the official NIEHS website footer components for easy use in Shiny applications.

## Installation

Install from source (after downloading/cloning this package):

```r
# Install devtools if needed
install.packages("devtools")

# Install niehsFooter from the local folder
devtools::install("path/to/niehsFooter")
```

Or build and install the `.tar.gz` directly:

```r
devtools::build("path/to/niehsFooter")        # creates niehsFooter_0.1.0.tar.gz
install.packages("niehsFooter_0.1.0.tar.gz", repos = NULL, type = "source")
```

---

## Usage

```r
library(shiny)
library(niehsFooter)

ui <- fluidPage(
  # Injects footer JS assets into <head>
  niehs_footer_tags(),

  # --- Your app content ---
  h2("My NIEHS Shiny App"),
  p("App content goes here."),

  # NIEHS footer at the bottom
  niehs_footer()
)

server <- function(input, output, session) {}

shinyApp(ui, server)
```

### Using both header and footer packages together

```r
library(shiny)
library(niehsHeader)
library(niehsFooter)

ui <- fluidPage(
  niehs_head_tags(),     # Header CSS/JS/meta
  niehs_footer_tags(),   # Footer JS

  niehs_header(),        # NIEHS nav bar

  # --- Your app content ---
  h2("My NIEHS Shiny App"),
  p("App content goes here."),

  niehs_footer()         # NIEHS footer
)

server <- function(input, output, session) {}
shinyApp(ui, server)
```

---

## Functions

| Function | Description |
|---|---|
| `niehs_footer_tags()` | **Recommended.** `<head>` block with footer JS assets. |
| `niehs_footer()` | The NIEHS footer HTML for the page body. |
| `niehs_footer_assets()` | Only the JS `<script>` tags (for manual `tags$head()` use). |

---

## Package Structure

```
niehsFooter/
├── DESCRIPTION
├── NAMESPACE
├── LICENSE
├── README.md
├── R/
│   └── niehs_footer.R      # All exported functions
└── inst/
    └── html/
        ├── footer.html      # NIEHS footer HTML
        └── footerasset.html # Footer JS script tags
```
