# niehsHeader

An R package that bundles the official NIEHS website header components for easy use in Shiny applications.

## Installation

Install from source (after downloading/cloning this package):

```r
# Install devtools if needed
install.packages("devtools")

# Install niehsHeader from the local folder
devtools::install("path/to/niehsHeader")
```

Or build and install the `.tar.gz` directly:

```r
devtools::build("path/to/niehsHeader")        # creates niehsHeader_0.1.0.tar.gz
install.packages("niehsHeader_0.1.0.tar.gz", repos = NULL, type = "source")
```

---

## Usage

```r
library(shiny)
library(niehsHeader)

ui <- fluidPage(
  # Injects NIEHS CSS, JS, and meta tags into <head>
  niehs_head_tags(),

  # Renders the full NIEHS navigation header bar
  niehs_header(),

  # --- Your app content below ---
  h2("My NIEHS Shiny App"),
  p("App content goes here.")
)

server <- function(input, output, session) {}

shinyApp(ui, server)
```

---

## Functions

| Function | Description |
|---|---|
| `niehs_head_tags()` | **Recommended.** Combined `<head>` block: meta tags + CSS/JS assets. |
| `niehs_header()` | The NIEHS navigation header HTML for the page body. |
| `niehs_header_meta()` | Only the meta/canonical/favicon `<head>` tags. |
| `niehs_header_assets()` | Only the CSS and JS `<link>`/`<script>` tags. |

---

## Package Structure

```
niehsHeader/
├── DESCRIPTION
├── NAMESPACE
├── LICENSE
├── README.md
├── R/
│   └── niehs_header.R      # All exported functions
└── inst/
    └── html/
        ├── header.html      # NIEHS navigation bar HTML
        ├── headerasset.html # CSS & JS asset tags
        └── headermeta.html  # Meta, canonical, favicon tags
```
