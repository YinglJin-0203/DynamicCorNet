#' Get path to an HTML file bundled with this package
#'
#' @param filename Name of the HTML file (e.g., "header.html")
#' @return Full file path as a character string
#' @keywords internal
html_path <- function(filename) {
  system.file("html", filename, package = "niehsHeader")
}

# -------------------------------------------------------------------------

#' NIEHS Header Body HTML
#'
#' Returns the full NIEHS navigation/header bar as an \code{htmltools::HTML}
#' object, ready to place at the top of a Shiny UI.
#'
#' @return An \code{\link[htmltools]{HTML}} object containing the NIEHS header.
#' @export
#' @examples
#' \dontrun{
#' library(shiny)
#' library(niehsHeader)
#'
#' ui <- fluidPage(
#'   niehs_head_tags(),   # CSS/JS assets + meta in <head>
#'   niehs_header()       # Navigation bar in <body>
#' )
#' }
niehs_header <- function() {
  path <- html_path("header.html")
  if (!file.exists(path)) stop("header.html not found in package inst/html/")
  htmltools::HTML(readLines(path, warn = FALSE, encoding = "UTF-8") |>
                    paste(collapse = "\n"))
}

# -------------------------------------------------------------------------

#' NIEHS Header Assets (CSS & JS)
#'
#' Returns the NIEHS stylesheet and script tags as an \code{htmltools::HTML}
#' object. Intended to be placed inside \code{tags$head()} or via
#' \code{\link{niehs_head_tags}}.
#'
#' @return An \code{\link[htmltools]{HTML}} object with \code{<link>} and
#'   \code{<script>} tags.
#' @export
#' @examples
#' \dontrun{
#' library(shiny)
#' library(niehsHeader)
#'
#' ui <- fluidPage(
#'   tags$head(niehs_header_assets()),
#'   niehs_header()
#' )
#' }
niehs_header_assets <- function() {
  path <- html_path("headerasset.html")
  if (!file.exists(path)) stop("headerasset.html not found in package inst/html/")
  htmltools::HTML(readLines(path, warn = FALSE, encoding = "UTF-8") |>
                    paste(collapse = "\n"))
}

# -------------------------------------------------------------------------

#' NIEHS Header Meta Tags
#'
#' Returns the NIEHS canonical link, favicon, viewport, and other \code{<meta>}
#' / \code{<link>} tags as an \code{htmltools::HTML} object. Intended to be
#' placed inside \code{tags$head()}.
#'
#' @return An \code{\link[htmltools]{HTML}} object with head meta elements.
#' @export
#' @examples
#' \dontrun{
#' library(shiny)
#' library(niehsHeader)
#'
#' ui <- fluidPage(
#'   tags$head(niehs_header_meta()),
#'   niehs_header()
#' )
#' }
niehs_header_meta <- function() {
  path <- html_path("headermeta.html")
  if (!file.exists(path)) stop("headermeta.html not found in package inst/html/")
  htmltools::HTML(readLines(path, warn = FALSE, encoding = "UTF-8") |>
                    paste(collapse = "\n"))
}

# -------------------------------------------------------------------------

#' All NIEHS Head Tags (assets + meta) Combined
#'
#' Convenience wrapper that returns a single \code{tags$head()} block
#' containing both the NIEHS CSS/JS assets and the NIEHS meta tags.
#' Drop this directly into your Shiny UI alongside \code{\link{niehs_header}}.
#'
#' @return A \code{\link[shiny]{tagList}} wrapping \code{tags$head(...)}.
#' @export
#' @examples
#' \dontrun{
#' library(shiny)
#' library(niehsHeader)
#'
#' ui <- fluidPage(
#'   niehs_head_tags(),
#'   niehs_header(),
#'   # ... rest of your UI
#' )
#'
#' server <- function(input, output, session) {}
#' shinyApp(ui, server)
#' }
niehs_head_tags <- function() {
  shiny::tags$head(
    niehs_header_meta(),
    niehs_header_assets()
  )
}
